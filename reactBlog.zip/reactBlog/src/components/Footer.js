function Footer(){
    return (
        <footer>
            <div class="row">
                <div class="col-sm-6 col-md-4 footer-navigation">
                    <h4><a href="#">Personal<span>Blog </span></a></h4>
                    <p class="links"><a href="./">Info</a><strong> · </strong><a href="contact">Contact</a><strong> · </strong><a href="company">Company</a><strong> · </strong></p>
                    <p class="company-name">ReactBlog © 2024 </p>
                </div>
                <div class="col-sm-6 col-md-4 footer-contacts">
                    <div><span class="fa fa-map-marker footer-contacts-icon"> </span>
                        <p><span class="new-line-span">Abdullah Hannan</span> Guwahati</p>
                    </div>
                    <div><i class="fa fa-phone footer-contacts-icon"></i>
                        <p class="footer-center-info email text-start"> XX (91) 8471869080</p>
                    </div>
                    <div><i class="fa fa-envelope footer-contacts-icon"></i>
                        <p> <a href="#" target="_blank">konmoni786@gmail.com</a></p>
                    </div>
                </div>
                <div class="col-md-4 footer-about">
                    <h4>Personal Blog</h4>
                    <p> A personal blog using React Js Flask/Python</p>
                    <div class="social-links social-icons"><a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-linkedin"></i></a><a href="#"><i class="fa fa-github"></i></a></div>
                </div>
            </div>
        </footer>
    )
}

export default Footer