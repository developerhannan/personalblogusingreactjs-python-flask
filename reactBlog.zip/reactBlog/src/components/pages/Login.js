import { useState } from "react"

function Login() {

  function abc(e){
    e.preventDefault()
    console.log(email, password)
  }

  const [email, setEmail] = useState()
  const [password, setPassword] = useState()


  return (
    <div>
      <div class="container d-flex justify-content-center">
        <div class="col-6">
          <form onSubmit={abc}>


            <div class="form-group row">
              <label for="email" class="col-sm-2 col-form-label">Email</label>
              <div class="col-sm-10">
                <input type="email" class="form-control" id="email" name="email" placeholder="Email" onChange={(e => setEmail(e.target.value))}/>
              </div>
            </div>

            <div class="form-group row">
              <label for="password" class="col-sm-2 col-form-label">Password</label>
              <div class="col-sm-10">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password" onChange={(e => setPassword(e.target.value))} />
              </div>
            </div>


            <div class="form-group row ">
            <button type="submit" class="btn btn-primary">Login</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  )
}


export default Login