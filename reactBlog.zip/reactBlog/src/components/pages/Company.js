function Company(){
    return <h1>About The COMPANY</h1>
}


export default Company