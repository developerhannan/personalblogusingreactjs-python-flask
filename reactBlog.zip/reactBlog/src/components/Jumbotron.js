function Jumbotron() {
    return (
        <div class="jumbotron jumbotron-fluid bg-dark mb-0">
             
        </div>
    )
}

export default Jumbotron